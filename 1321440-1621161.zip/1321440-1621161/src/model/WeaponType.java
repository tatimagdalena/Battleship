package model;

public enum WeaponType {
	couracado, cruzador, destroyer, hidroaviao, submarino, generico
}
