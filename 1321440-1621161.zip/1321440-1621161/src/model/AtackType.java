package model;

public enum AtackType {
	hit, water, empty
}
