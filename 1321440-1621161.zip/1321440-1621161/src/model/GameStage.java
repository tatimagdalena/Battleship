package model;

public enum GameStage {
	naming, positioning, battle
}
