package model;

public enum PlayerTurn {
	first, second
}
